public class Fraction{
	int numerateur;
	int denominateur;
	
	Fraction(int numerateur,int denominateur){
		this.numerateur=numerateur;
		this.denominateur=denominateur;
		}
	public String toString(){
		return "Numérateur:"+numerateur+"\n"+"Denominateur:"+denominateur+"\n";
		
		}
	
	}
