public class Main{
	
	public static void main(String args[]){
		Fraction test=new Fraction(14,3);
		System.out.print(test.toString());
		
		
		}
	
	
	}
