# SimpleFraction
This is a java project.We want to implement Fraction in java.
